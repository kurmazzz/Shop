from django.db import models
from datetime import datetime

# Create your models here.

class Product(models.Model):
    product_code = models.CharField(max_length=255, primary_key=True, verbose_name='Артикул')
    size = models.CharField(max_length=255, verbose_name='Размер обуви', default=36)
    name = models.CharField(max_length=255, verbose_name='Наименование товара')
    price = models.IntegerField(verbose_name='Розничная цена', default=1)
    count = models.IntegerField(verbose_name='Кол-во товара', default=1)
    country = models.CharField(max_length=255, verbose_name='Страна производителя', default=1)
    manufacturer = models.CharField(max_length=255, verbose_name='Производитель')

    GENDER_TYPES =(
        ('0', 'Мужской'),
        ('1', 'Женский')
    )

    type_gender = models.CharField(max_length=1, choices=GENDER_TYPES, verbose_name='Тип обуви')

    class Meta:
        verbose_name = 'Продукт'
        verbose_name_plural = 'Продукты'

    def __str__(self):
        return str(self.name)

class Employee(models.Model):
    id = models.AutoField(primary_key=True, verbose_name = 'Номер сотрудника')
    name = models.CharField(max_length=255, verbose_name='ФИО')
    position = models.CharField(max_length=255, verbose_name='Должность')
    salary = models.IntegerField(verbose_name='Зарплата', default=1)
    phone = models.CharField(max_length=255, verbose_name='Телефон')
    date = models.DateTimeField(verbose_name='Дата приёма на работу', default=datetime.now)

    class Meta:
        verbose_name = 'Работник'
        verbose_name_plural = 'Работники'

    def __str__(self):
        return str(self.name)

class Sale(models.Model):
    id = models.AutoField(primary_key=True, verbose_name='Код продажи')
    product_code = models.ForeignKey(Product, on_delete=models.DO_NOTHING, verbose_name='Артикул')
    count = models.CharField(max_length=255, verbose_name='Кол-во проданного товара', default=1)
    date = models.DateTimeField(verbose_name='Время продажи', default=datetime.now)
    cost = models.IntegerField(verbose_name='Сумма продажи', default=1)
    employee_id = models.ForeignKey(Employee, on_delete=models.DO_NOTHING, verbose_name='ФИО сотрудника')

    class Meta:
        verbose_name = 'Продажа'
        verbose_name_plural = 'Продажи'

    def __str__(self):
        return str(self.id)

class Supply(models.Model):
    id = models.AutoField (primary_key='True', verbose_name = 'Код поставки')
    product_code = models.ForeignKey(Product,on_delete=models.CASCADE, verbose_name='Имя товара')
    cost_of_receipt = models.IntegerField(verbose_name='Цена за одну единицу')
    total_cost = models.IntegerField(verbose_name='Общая сумма поставки')
    count = models.IntegerField(verbose_name='Кол-во товара')
    date = models.DateField(verbose_name='Дата поставки')

    class Meta:
        verbose_name = 'Поставка'
        verbose_name_plural = 'Поставки'

    def __str__(self):
        return str(self.product_code) + ' Код поставки: ' +str(self.id)