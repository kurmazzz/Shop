from django.apps import AppConfig


class IsConfig(AppConfig):
    name = 'IS'
