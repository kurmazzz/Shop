from django.contrib import admin
from .models import Product, Supply, Employee, Sale

admin.site.site_header = 'Информационная система обувного магазина'
admin.site.site_title = 'Магазин'

# Register your models here.
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('product_code', 'name', 'size', 'type_gender')
    search_fields = ['product_code']

@admin.register(Supply)
class SupplyAdmin(admin.ModelAdmin):
    list_display = ('id', 'product_code', 'total_cost', 'date')
    search_fields = ['id']

@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ('id', 'product_code', 'count', 'date')
    search_fields = ['id']

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'position', 'date')
    search_fields = ['position']